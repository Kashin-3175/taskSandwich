package taskSandwich;

import data.LoginFrame;
import util.DbConn;
import vo.VoSandwich;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class MainSandwich extends JFrame {
    private JList<String> breadList;
    private JList<String> vegetablesList;
    private JList<String> meatList;
    private JList<String> sauceList;

    private JTextField breadField;
    private JTextField vegetable1Field;
    private JTextField vegetable2Field;
    private JTextField vegetable3Field;
    private JTextField meatField;
    private JTextField sauce1Field;
    private JTextField sauce2Field;

    private JLabel totalLabel;
    private Map<String, Integer> prices;
    private int totalAmount;

    private JPanel rightPanel;
    private JPanel bottomPanel;

    private VoSandwich voSandwich;

    public MainSandwich() {
        setTitle("サンドイッチ作成システム");
        setSize(700, 500);
        setLocationRelativeTo(null);

        prices = new HashMap<>();
        voSandwich = new VoSandwich();

        breadList = new JList<>();
        vegetablesList = new JList<>();
        meatList = new JList<>();
        sauceList = new JList<>();

        breadField = new JTextField(10);
        vegetable1Field = new JTextField(10);
        vegetable2Field = new JTextField(10);
        vegetable3Field = new JTextField(10);
        meatField = new JTextField(10);
        sauce1Field = new JTextField(10);
        sauce2Field = new JTextField(10);

        totalLabel = new JLabel("金額: 0円");

        // レイアウトの初期化
        initializeRightPanel();
        initializeAddButton();

        JPanel leftPanel = new JPanel(new GridLayout(1, 4));
        leftPanel.setBackground(Color.WHITE);

        JScrollPane breadScrollPane = new JScrollPane(breadList);
        JScrollPane vegetablesScrollPane = new JScrollPane(vegetablesList);
        JScrollPane meatScrollPane = new JScrollPane(meatList);
        JScrollPane sauceScrollPane = new JScrollPane(sauceList);

        leftPanel.add(createCategoryPanel("パン", breadScrollPane));
        leftPanel.add(createCategoryPanel("野菜", vegetablesScrollPane));
        leftPanel.add(createCategoryPanel("肉", meatScrollPane));
        leftPanel.add(createCategoryPanel("ソース", sauceScrollPane));

        setLayout(new BorderLayout());
        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        loadMaterialsFromDatabase();

        setVisible(true);
    }

    private JPanel createCategoryPanel(String category, JScrollPane scrollPane) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        JLabel label = new JLabel(category, SwingConstants.CENTER);
        panel.add(label, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private void initializeRightPanel() {
        rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        rightPanel.add(new JLabel("bread"), gbc);

        gbc.gridx = 1;
        rightPanel.add(breadField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        rightPanel.add(new JLabel("vegetable1"), gbc);

        gbc.gridx = 1;
        rightPanel.add(vegetable1Field, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        rightPanel.add(new JLabel("vegetable2"), gbc);

        gbc.gridx = 1;
        rightPanel.add(vegetable2Field, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        rightPanel.add(new JLabel("vegetable3"), gbc);

        gbc.gridx = 1;
        rightPanel.add(vegetable3Field, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        rightPanel.add(new JLabel("meat"), gbc);

        gbc.gridx = 1;
        rightPanel.add(meatField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        rightPanel.add(new JLabel("sauce1"), gbc);

        gbc.gridx = 1;
        rightPanel.add(sauce1Field, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        rightPanel.add(new JLabel("sauce2"), gbc);

        gbc.gridx = 1;
        rightPanel.add(sauce2Field, gbc);
    }

    private void initializeAddButton() {
        JButton addButton = new JButton("カートに追加");
        JButton clearButton = new JButton("クリア");
        JButton changeBuyButton = new JButton("購入");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
                updateTotalAmount();
            }
        });
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addOrderToDatabase();
            }
        });
        changeBuyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new BuySandwich();
            }
        });

        bottomPanel = new JPanel();
        bottomPanel.add(clearButton);
        bottomPanel.add(addButton);
        bottomPanel.add(changeBuyButton);
        bottomPanel.add(totalLabel);

        addListeners();
    }

    private void addListeners() {
        breadList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    breadField.setText(breadList.getSelectedValue());
                    updateTotalAmount();
                }
            }
        });

        vegetablesList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    String selectedValue = vegetablesList.getSelectedValue();
                    if (vegetable1Field.getText().isEmpty()) {
                        vegetable1Field.setText(selectedValue);
                    } else if (vegetable2Field.getText().isEmpty()) {
                        vegetable2Field.setText(selectedValue);
                    } else {
                        vegetable3Field.setText(selectedValue);
                    }
                    updateTotalAmount();
                }
            }
        });

        meatList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    meatField.setText(meatList.getSelectedValue());
                    updateTotalAmount();
                }
            }
        });

        sauceList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    String selectedValue = sauceList.getSelectedValue();
                    if (sauce1Field.getText().isEmpty()) {
                        sauce1Field.setText(selectedValue);
                    } else {
                        sauce2Field.setText(selectedValue);
                    }
                    updateTotalAmount();
                }
            }
        });
    }

    private void clearFields() {
        breadField.setText("");
        vegetable1Field.setText("");
        vegetable2Field.setText("");
        vegetable3Field.setText("");
        meatField.setText("");
        sauce1Field.setText("");
        sauce2Field.setText("");
    }

    private void updateTotalAmount() {
        totalAmount = 0;

        totalAmount += prices.getOrDefault(breadField.getText(), 0);
        totalAmount += prices.getOrDefault(vegetable1Field.getText(), 0);
        totalAmount += prices.getOrDefault(vegetable2Field.getText(), 0);
        totalAmount += prices.getOrDefault(vegetable3Field.getText(), 0);
        totalAmount += prices.getOrDefault(meatField.getText(), 0);
        totalAmount += prices.getOrDefault(sauce1Field.getText(), 0);
        totalAmount += prices.getOrDefault(sauce2Field.getText(), 0);

        totalLabel.setText("金額: " + totalAmount + "円");

        voSandwich.setTotalAmount(totalAmount);
    }

    private void loadMaterialsFromDatabase() {
        try {
            Statement statement = DbConn.conn.createStatement();

            String query = "SELECT * FROM materials";
            ResultSet resultSet = statement.executeQuery(query);

            DefaultListModel<String> breadModel = new DefaultListModel<>();
            DefaultListModel<String> vegetablesModel = new DefaultListModel<>();
            DefaultListModel<String> meatModel = new DefaultListModel<>();
            DefaultListModel<String> sauceModel = new DefaultListModel<>();

            while (resultSet.next()) {
                int category = resultSet.getInt("categoly");
                String material = resultSet.getString("materials");
                int price = resultSet.getInt("price");
                prices.put(material, price);

                switch (category) {
                    case 0:
                        breadModel.addElement(material);
                        break;
                    case 1:
                        vegetablesModel.addElement(material);
                        break;
                    case 2:
                        meatModel.addElement(material);
                        break;
                    case 3:
                        sauceModel.addElement(material);
                        break;
                }
            }

            breadList.setModel(breadModel);
            vegetablesList.setModel(vegetablesModel);
            meatList.setModel(meatModel);
            sauceList.setModel(sauceModel);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addOrderToDatabase() {
        String insertQuery = "INSERT INTO userorder (order_id, bread, vegetables1, vegetables2, vegetables3, meat, souce1, souce2, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
             PreparedStatement preparedStatement = DbConn.conn.prepareStatement(insertQuery);

            preparedStatement.setString(1, LoginFrame.logIn);  // ログイン画面から取得した実際のIDに置き換えてください
            preparedStatement.setString(2, breadField.getText());
            preparedStatement.setString(3, vegetable1Field.getText());
            preparedStatement.setString(4, vegetable2Field.getText());
            preparedStatement.setString(5, vegetable3Field.getText());
            preparedStatement.setString(6, meatField.getText());
            preparedStatement.setString(7, sauce1Field.getText());
            preparedStatement.setString(8, sauce2Field.getText());
            preparedStatement.setString(9, "0");

            preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(null, "注文が追加されました!");

            clearFields();
            updateTotalAmount();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "データベースへの注文追加中にエラーが発生しました。");
        }
    }

    public static void main(String[] args) {
        new MainSandwich();
    }
}
