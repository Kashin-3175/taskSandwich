package taskSandwich;

import data.LoginFrame;
import util.DbConn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginSandwich extends JFrame {
    public LoginSandwich() {
        DbConn.getConnection();
        setTitle("ログインフレーム");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // JFrameの背景色を白に設定
        getContentPane().setBackground(Color.WHITE);

        JPanel mainP = new JPanel(new GridLayout(1, 2));
        mainP.setBackground(Color.WHITE); // mainPの背景色を白に設定

        JPanel p1 = new JPanel(new GridLayout(2, 1));
        p1.setBackground(Color.WHITE); // p1の背景色を白に設定

        JPanel p11 = new JPanel(new GridLayout(4, 2));
        p11.setBackground(Color.WHITE); // p11の背景色を白に設定
        JPanel p111 = new JPanel();
        p111.setBackground(Color.WHITE); // p111の背景色を白に設定

        JLabel l1 = new JLabel("IDを入力");
        JTextField t1 = new JTextField(10);

        JPanel p112 = new JPanel();
        p112.setBackground(Color.WHITE); // p112の背景色を白に設定
        JPanel p113 = new JPanel();
        p113.setBackground(Color.WHITE); // p113の背景色を白に設定
        JPanel p114 = new JPanel();
        p114.setBackground(Color.WHITE); // p114の背景色を白に設定
        JPanel p115 = new JPanel();
        p115.setBackground(Color.WHITE); // p114の背景色を白に設定
        JPanel p116 = new JPanel();
        p116.setBackground(Color.WHITE); // p114の背景色を白に設定
        JPanel p117 = new JPanel();
        p117.setBackground(Color.WHITE); // p114の背景色を白に設定JPanel p114 = new JPanel();
        JPanel p118 = new JPanel();
        p118.setBackground(Color.WHITE); // p114の背景色を白に設定JPanel p114 = new JPanel();
        p114.setBackground(Color.WHITE); // p114の背景色を白に設定



        JLabel l2 = new JLabel("passwordを入力");
        JPasswordField ps1 = new JPasswordField(10);

        p113.add(l1);
        p114.add(t1);
        p115.add(l2);
        p116.add(ps1);

        p11.add(p111);
        p11.add(p112);
        p11.add(p113);
        p11.add(p114);
        p11.add(p115);
        p11.add(p116);
        p11.add(p117);
        p11.add(p118);

        JPanel p12 = new JPanel(new GridLayout(3, 1));
        p12.setBackground(Color.WHITE); // p12の背景色を白に設定

        JPanel p121 = new JPanel();
        p121.setBackground(Color.WHITE); // p121の背景色を白に設定

        JButton b1 = new JButton("ログイン");

        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id1 = t1.getText();
                String password1 = new String(ps1.getPassword());
                String sql = "select * from userinfomation where id = ? and password = ?";

                try {
                    PreparedStatement ps = DbConn.conn.prepareStatement(sql);
                    ps.setString(1, id1);
                    ps.setString(2, password1);
                    ResultSet rs = ps.executeQuery();

                    if (rs.next()){
                        JOptionPane.showMessageDialog(null, "ログインしました");
                        LoginFrame.logIn = id1;
                        dispose();
                        new MainSandwich();
                    }else {
                        JOptionPane.showMessageDialog(null, "ログインに失敗しました");
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });
        p121.add(b1);

        JPanel p122 = new JPanel();
        p122.setBackground(Color.WHITE); // p122の背景色を白に設定

        JButton b2 = new JButton("新規登録");
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new ResisterSandwich();
            }
        });
        p122.add(b2);

        JPanel p123 = new JPanel();
        p123.setBackground(Color.WHITE); // p123の背景色を白に設定

        JButton b3 = new JButton("ログインしない");
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoginFrame.logIn = "ゲスト";
                guestMehtod();
                dispose();
                new MainSandwich();

            }
        });
        p123.add(b3);

        p12.add(p121);
        p12.add(p122);
        p12.add(p123);

        p1.add(p11);
        p1.add(p12);

        // p2はサンドウィッチ店の画像を当て込む
        JPanel p2 = new ImagePanel("src/sandwichMain.png"); // 画像ファイルのパスを指定
        p2.setBackground(Color.WHITE); // p2の背景色を白に設定

        mainP.add(p1);
        mainP.add(p2);

        add(mainP);

        setVisible(true);
    }

    public static void main(String[] args) {
        new LoginSandwich();
    }

    // カスタムパネルクラス
    private static class ImagePanel extends JPanel {
        private BufferedImage image;

        public ImagePanel(String imagePath) {
            try {
                image = ImageIO.read(new File(imagePath));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (image != null) {
                int x = (getWidth() - image.getWidth()) / 2;
                int y = (getHeight() - image.getHeight()) / 2;
                g.drawImage(image, x, y, this);
            }
        }
    }
    private void guestMehtod(){
        String query = "INSERT INTO userinfomation (id, password) VALUES (?, ?)";

        try {
            PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
            preparedStatement.setString(1, LoginFrame.logIn);
            preparedStatement.setString(2, "1234");
            preparedStatement.executeUpdate();

            JOptionPane.showMessageDialog(null, "ゲストで始めます");

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "エラーが発生しました");
        }
    }
}
