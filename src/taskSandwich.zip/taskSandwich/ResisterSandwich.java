package taskSandwich;

import util.DbConn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ResisterSandwich extends JFrame {
    private JTextField idField;
    private JPasswordField pwField;
    private JPasswordField pw2Field;
    private JTextField emailField;
    private JTextField addressField;
    private JTextField numberField;

    public ResisterSandwich() {
        setTitle("会員登録");
        setSize(700, 500);
        setLocationRelativeTo(null);

        // Create components
        JLabel titleLabel = new JLabel("タイトル", SwingConstants.CENTER);
        JLabel idLabel = new JLabel("ID", SwingConstants.CENTER);
        JLabel pwLabel = new JLabel("PW", SwingConstants.CENTER);
        JLabel pw2Label = new JLabel("PW2", SwingConstants.CENTER);
        JLabel emailLabel = new JLabel("Email", SwingConstants.CENTER);
        JLabel addressLabel = new JLabel("Adress", SwingConstants.CENTER);
        JLabel numberLabel = new JLabel("Number", SwingConstants.CENTER);

        idField = new JTextField(20);
        pwField = new JPasswordField(20);
        pw2Field = new JPasswordField(20);
        emailField = new JTextField(20);
        addressField = new JTextField(20);
        numberField = new JTextField(20);

        JButton backButton = new JButton("←戻る");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "ログイン画面に戻ります");
                dispose();
                new LoginSandwich();
            }
        });
        JButton registerButton = new JButton("登録");
        registerButton.addActionListener(new RegisterAction());

        // Image panel
        JPanel imagePanel = new JPanel();
        ImageIcon imageIcon = new ImageIcon(new ImageIcon("src/n.png").getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH));
        JLabel imageLabel = new JLabel(imageIcon);
        imagePanel.add(imageLabel);

        // Layout setup
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;
        add(idLabel, gbc);
        gbc.gridx = 1;
        add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(pwLabel, gbc);
        gbc.gridx = 1;
        add(pwField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(pw2Label, gbc);
        gbc.gridx = 1;
        add(pw2Field, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(emailLabel, gbc);
        gbc.gridx = 1;
        add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(addressLabel, gbc);
        gbc.gridx = 1;
        add(addressField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(numberLabel, gbc);
        gbc.gridx = 1;
        add(numberField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 1;
        add(backButton, gbc);

        gbc.gridx = 1;
        add(registerButton, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridheight = 7;
        add(imagePanel, gbc);

        setVisible(true);
    }

    private class RegisterAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String id = idField.getText().trim();
            String pw = new String(pwField.getPassword()).trim();
            String pw2 = new String(pw2Field.getPassword()).trim();
            String email = emailField.getText().trim();
            String address = addressField.getText().trim();
            String number = numberField.getText().trim();

            if (!pw.equals(pw2)) {
                JOptionPane.showMessageDialog(null, "Passwords do not match!");
                return;
            }

            saveUserInfo(id, pw, email, address, number);
        }

        private void saveUserInfo(String id, String pw, String email, String address, String number) {


            String query = "INSERT INTO userinfomation (id, password, email, address, number) VALUES (?, ?, ?, ?, ?)";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setString(1, id);
                preparedStatement.setString(2, pw);
                preparedStatement.setString(3, email);
                preparedStatement.setString(4, address);
                preparedStatement.setString(5, number);
                preparedStatement.executeUpdate();

                JOptionPane.showMessageDialog(null, "Registration successful!");

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "登録中にエラーが発生しました。");
            }
        }
    }

    public static void main(String[] args) {
        new ResisterSandwich();
    }
}
