package taskSandwich;

import data.LoginFrame;
import util.DbConn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class PaymentSandwich extends JFrame {
    private JTextField creditField;
    private JTextField prepaidField;
    private JComboBox<String> creditAmountComboBox;
    private JLabel balanceLabel;
    private int currentBalance;

    public PaymentSandwich() {
        setTitle("決済方法");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create components
        JLabel idLabel = new JLabel("ID:" + LoginFrame.logIn, SwingConstants.CENTER); // Use the actual user ID
        JLabel creditLabel = new JLabel("クレジット", SwingConstants.CENTER);
        JLabel prepaidLabel = new JLabel("プリペイド", SwingConstants.CENTER);

        creditField = new JTextField(20);
        prepaidField = new JTextField(20);

        String[] amounts = {"1000", "3000", "5000"};
        creditAmountComboBox = new JComboBox<>(amounts);

        JButton checkButton = new JButton("確認");
        JButton backButton = new JButton("戻る");
        JButton addButton = new JButton("Add");

        checkButton.addActionListener(new CheckAction());
        addButton.addActionListener(new AddAction());

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new BuySandwich();
            }
        });

        // Load credit number and current balance from userinfomation table
        String creditNumber = loadCreditNumber(LoginFrame.logIn); // Use the actual user ID
        currentBalance = loadCurrentBalance(LoginFrame.logIn);
        creditField.setText(creditNumber);

        balanceLabel = new JLabel("残額: " + currentBalance + "円", SwingConstants.CENTER);

        // Layout setup
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(idLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;
        add(creditLabel, gbc);

        gbc.gridx = 1;
        add(creditField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(new JLabel("金額", SwingConstants.CENTER), gbc);

        gbc.gridx = 1;
        add(creditAmountComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(prepaidLabel, gbc);

        gbc.gridx = 1;
        add(prepaidField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(checkButton, gbc);

        gbc.gridy++;
        gbc.gridwidth = 2;
        add(balanceLabel, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        add(backButton, gbc);

        gbc.gridx = 1;
        add(addButton, gbc);

        setVisible(true);
    }

    private String loadCreditNumber(String userId) {
        String creditNumber = "";

        String query = "SELECT credit FROM userinfomation WHERE id = ?";

        try {
            PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
            preparedStatement.setString(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                creditNumber = resultSet.getString("credit");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "クレジット番号の読み込み中にエラーが発生しました。");
        }
        return creditNumber;
    }

    private int loadCurrentBalance(String userId) {
        int balance = 0;

        String query = "SELECT price FROM userinfomation WHERE id = ?";

        try {
            PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
            preparedStatement.setString(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                balance = resultSet.getInt("price");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "残額の読み込み中にエラーが発生しました。");
        }
        return balance;
    }

    private class CheckAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String prepaidCode = prepaidField.getText().trim();
            if (prepaidCode.isEmpty()) {
                JOptionPane.showMessageDialog(null, "プリペイドコードを入力してください。");
                return;
            }

            int prepaidAmount = getPrepaidAmount(prepaidCode);

            currentBalance += prepaidAmount;
            balanceLabel.setText("残額: " + currentBalance + "円");

            JOptionPane.showMessageDialog(null, "プリペイドコードに対応する金額が残額に追加されました。");
        }

        private int getPrepaidAmount(String code) {
            int amount = 0;

            String query = "SELECT price FROM pripaid WHERE code = ?";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setString(1, code);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    amount = resultSet.getInt("price");
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "プリペイドコードの読み込み中にエラーが発生しました。");
            }
            return amount;
        }
    }

    private class AddAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (creditField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "クレジット番号を入力してください。");
                return;
            }

            int creditAmount = Integer.parseInt((String) creditAmountComboBox.getSelectedItem());

            currentBalance += creditAmount;

            // Save the new balance to the database
            saveNewBalance(LoginFrame.logIn, currentBalance);

            balanceLabel.setText("残額: " + currentBalance + "円");

            JOptionPane.showMessageDialog(null, "料金が追加されました。");

            // Navigate to BuySandwich
            new BuySandwich();
            dispose();
        }

        private void saveNewBalance(String userId, int newBalance) {

            String query = "UPDATE userinfomation SET price = ? WHERE id = ?";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setInt(1, newBalance);
                preparedStatement.setString(2, userId);
                preparedStatement.executeUpdate();

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "残額の保存中にエラーが発生しました。");
            }
        }
    }

    public static void main(String[] args) {
        new PaymentSandwich();
    }
}
