package taskSandwich;

import data.LoginFrame;
import util.DbConn;
import vo.VoSandwich;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class BuySandwich extends JFrame {
    private JTable orderTable;
    private JTable pastOrdersTable;
    private JTextField addressField;
    private JTextField deliveryDateField;
    private JCheckBox agreeTermsCheckBox;

    public BuySandwich() {
        DbConn.getConnection();
        setTitle("購入確認");
        setSize(700, 600); // Increased size to accommodate the new table
        setLocationRelativeTo(null);

        // Retrieve and display order details
        // Load and display past orders
        Map<String, Vector<Vector<String>>> pastOrderData = loadPastOrderData(LoginFrame.logIn);

        Vector<Vector<String>> pastOrder = pastOrderData.get("1");
        Vector<Vector<String>> ordered = pastOrderData.get("0");
        Vector<String> columnNames = new Vector<>();
        columnNames.add("パン");
        columnNames.add("野菜1");
        columnNames.add("野菜2");
        columnNames.add("野菜3");
        columnNames.add("肉");
        columnNames.add("ソース1");
        columnNames.add("ソース2");

        orderTable = new JTable(ordered, columnNames);
        JScrollPane tableScrollPane = new JScrollPane(orderTable);

        // Retrieve and display user address
        String address = loadUserAddress(LoginFrame.logIn); // Use the actual user ID
        addressField = new JTextField(address, 30);
        addressField.setEditable(true); // Make the address field editable

        // Delivery date input
        deliveryDateField = new JTextField(30);

        // Agree to terms checkbox
        agreeTermsCheckBox = new JCheckBox("利用規約に同意します");

        Vector<String> pastOrderColumnNames = new Vector<>();
        pastOrderColumnNames.add("パン");
        pastOrderColumnNames.add("野菜1");
        pastOrderColumnNames.add("野菜2");
        pastOrderColumnNames.add("野菜3");
        pastOrderColumnNames.add("肉");
        pastOrderColumnNames.add("ソース1");
        pastOrderColumnNames.add("ソース2");

        pastOrdersTable = new JTable(pastOrder, pastOrderColumnNames);
        JScrollPane pastOrdersScrollPane = new JScrollPane(pastOrdersTable);

        // Layout setup
        setLayout(new BorderLayout());
        JPanel mainPanel = new JPanel(new GridLayout(2, 1));
        mainPanel.add(tableScrollPane);
        mainPanel.add(pastOrdersScrollPane);
        add(mainPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new GridLayout(5, 1));
        bottomPanel.add(new JLabel("住所:"));
        bottomPanel.add(addressField);
        bottomPanel.add(new JLabel("配送日時:"));
        bottomPanel.add(deliveryDateField);
        bottomPanel.add(agreeTermsCheckBox);

        JPanel buttonPanel = new JPanel();
        JButton purchaseButton = new JButton("購入");
        JButton returnButton = new JButton("決済登録");
        JButton resetButton = new JButton("追加しなおす");

        purchaseButton.addActionListener(new PurchaseAction());
        returnButton.addActionListener(e -> {
            dispose();
            new PaymentSandwich();
        });
        resetButton.addActionListener(new ResetAction());

        buttonPanel.add(purchaseButton);
        buttonPanel.add(returnButton);
        buttonPanel.add(resetButton);

        add(bottomPanel, BorderLayout.SOUTH);
        add(buttonPanel, BorderLayout.NORTH);

        setVisible(true);
    }

    private Vector<Vector<String>> loadOrderData(String userId) {
        Vector<Vector<String>> data = new Vector<>();

        String query = "SELECT bread, vegetables1, vegetables2, vegetables3, meat, souce1, souce2 FROM userorder WHERE order_id = ? and status = ?";

        try {
            PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
            preparedStatement.setString(1, userId);
            preparedStatement.setString(2, "0");

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Vector<String> row = new Vector<>();
                row.add(resultSet.getString("bread"));
                row.add(resultSet.getString("vegetables1"));
                row.add(resultSet.getString("vegetables2"));
                row.add(resultSet.getString("vegetables3"));
                row.add(resultSet.getString("meat"));
                row.add(resultSet.getString("souce1"));
                row.add(resultSet.getString("souce2"));
                data.add(row);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "注文データの読み込み中にエラーが発生しました。");
        }
        return data;
    }

    private Map<String, Vector<Vector<String>>> loadPastOrderData(String userId) {
        Map<String, Vector<Vector<String>>> resultMap = new HashMap<>();
        Vector<Vector<String>> orderedVector = new Vector<>();
        Vector<Vector<String>> orderVector = new Vector<>();

        String query = "SELECT order_id, bread, vegetables1, vegetables2, vegetables3, meat, souce1, souce2, status FROM userorder WHERE order_id = ?";

        try {
            PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
            preparedStatement.setString(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Vector<String> row = new Vector<>();
                row.add(resultSet.getString("bread"));
                row.add(resultSet.getString("vegetables1"));
                row.add(resultSet.getString("vegetables2"));
                row.add(resultSet.getString("vegetables3"));
                row.add(resultSet.getString("meat"));
                row.add(resultSet.getString("souce1"));
                row.add(resultSet.getString("souce2"));
                if (resultSet.getString("status").equals("0")) {
                    orderVector.add(row);
                } else {
                    orderedVector.add(row);
                }
            }

            resultMap.put("0", orderVector);
            resultMap.put("1", orderedVector);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "過去の注文データの読み込み中にエラーが発生しました。");
        }
        return resultMap;
    }

    private String loadUserAddress(String userId) {
        String address = "";
        String query = "SELECT address FROM userinfomation WHERE id = ?";

        try {
            PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
            preparedStatement.setString(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                address = resultSet.getString("address");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "住所データの読み込み中にエラーが発生しました。");
        }
        return address;
    }

    private class PurchaseAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!agreeTermsCheckBox.isSelected()) {
                JOptionPane.showMessageDialog(null, "利用規約に同意してください。");
                return;
            }

            String deliveryDate = deliveryDateField.getText().trim();
            if (deliveryDate.isEmpty()) {
                JOptionPane.showMessageDialog(null, "配送日時を入力してください。");
                return;
            }

            // VoSandwich インスタンスから合計金額を取得
            VoSandwich voSandwich = new VoSandwich();
            double totalAmount = voSandwich.getTotalAmount();

            // ユーザーの価格を取得
            double userPrice = getUserPrice(LoginFrame.logIn);

            // 購入金額が足りるか確認
            if (userPrice < totalAmount) {
                JOptionPane.showMessageDialog(null, "残額が足りません。");
                return;
            }

            // 金額を引いて再格納
            double newPrice = userPrice - totalAmount;
            updateUserPrice(LoginFrame.logIn, newPrice);

            // 他の処理
            saveDeliveryDate(LoginFrame.logIn, deliveryDate);
            updateOrderStatus(LoginFrame.logIn, "1");

            if (LoginFrame.logIn.equals("ゲスト")) {
                deleteGuestOrders();
            }

            JFrame thankYouFrame = new JFrame("お買い上げありがとうございます");
            thankYouFrame.setSize(300, 200);
            thankYouFrame.setLocationRelativeTo(null);

            JLabel thankYouLabel = new JLabel("お買い上げありがとうございます", SwingConstants.CENTER);
            thankYouFrame.add(thankYouLabel, BorderLayout.CENTER);

            JButton confirmButton = new JButton("確認");
            confirmButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    deleteMethod();
                    thankYouFrame.dispose();
                    dispose();
                    new LoginSandwich();
                }
            });
            thankYouFrame.add(confirmButton, BorderLayout.SOUTH);
            thankYouFrame.setVisible(true);
        }

        private double getUserPrice(String userId) {
            double price = 0.0;
            String query = "SELECT price FROM userinfomation WHERE id = ?";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setString(1, userId);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    price = resultSet.getDouble("price");
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "価格の取得中にエラーが発生しました。");
            }
            return price;
        }

        private void updateUserPrice(String userId, double newPrice) {
            String query = "UPDATE userinfomation SET price = ? WHERE id = ?";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setDouble(1, newPrice);
                preparedStatement.setString(2, userId);
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "価格の更新中にエラーが発生しました。");
            }
        }

        private void saveDeliveryDate(String userId, String deliveryDate) {
            String query = "UPDATE userorder SET delivery = ? WHERE order_id = ?";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setString(1, deliveryDate);
                preparedStatement.setString(2, userId);
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "配送日時の保存中にエラーが発生しました。");
            }
        }

        private void updateOrderStatus(String userId, String status) {
            String query = "UPDATE userorder SET status = ? WHERE order_id = ? AND status = '0'";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setString(1, status);
                preparedStatement.setString(2, userId);
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "注文ステータスの更新中にエラーが発生しました。");
            }
        }

        private void deleteGuestOrders() {
            String query = "DELETE FROM userorder WHERE order_id = ?";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setString(1, "ゲスト");
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "ゲストの注文データの削除中にエラーが発生しました。");
            }
        }

        private void deleteMethod() {
            String sql = "DELETE FROM userinfomation WHERE id = ?";
            String sql1 = "DELETE FROM userorder WHERE order_id = ?";

            try {
                PreparedStatement ps = DbConn.conn.prepareStatement(sql);
                ps.setString(1, "ゲスト"); // Use current logged-in user ID
                ps.executeUpdate();
                PreparedStatement ps2 = DbConn.conn.prepareStatement(sql1);
                ps2.setString(1, "ゲスト"); // Use current logged-in user ID
                ps2.executeUpdate();
                LoginFrame.logIn = ""; // Clear the logged-in user ID
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "ユーザー情報の削除中にエラーが発生しました。");
            }
        }
    }


    private class ResetAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            resetOrderData(LoginFrame.logIn);

            // Navigate back to MainSandwich
            dispose();
            new MainSandwich();
        }

        private void resetOrderData(String userId) {
            String query = "DELETE FROM userorder WHERE order_id = ? AND status = '0'";

            try {
                PreparedStatement preparedStatement = DbConn.conn.prepareStatement(query);
                preparedStatement.setString(1, userId);
                preparedStatement.executeUpdate();

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "注文データのリセット中にエラーが発生しました。");
            }
        }
    }

    public static void main(String[] args) {
        new BuySandwich();
    }
}
